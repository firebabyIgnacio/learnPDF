package com.tuling.mongodbdemo2.entity;

import java.util.LinkedHashMap;

/**
 * @author Fox
 */
public class UserAttrs extends LinkedHashMap<String,Object> {
}
