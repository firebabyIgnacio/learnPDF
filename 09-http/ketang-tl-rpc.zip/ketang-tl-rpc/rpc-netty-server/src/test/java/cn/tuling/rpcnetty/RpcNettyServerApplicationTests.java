package cn.tuling.rpcnetty;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RpcNettyServerApplicationTests {

    @Test
    void contextLoads() {
    }

}
