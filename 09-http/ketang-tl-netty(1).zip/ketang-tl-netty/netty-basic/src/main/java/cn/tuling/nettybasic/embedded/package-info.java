/**
 * @author Mark老师
 * 类说明：演示EmbeddedChannel的各种业务Handler，
 * 测试代码放在test目录下同名包中
 */
package cn.tuling.nettybasic.embedded;