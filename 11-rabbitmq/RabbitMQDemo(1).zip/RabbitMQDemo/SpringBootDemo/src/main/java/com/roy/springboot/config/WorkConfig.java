package com.roy.springboot.config;

public class WorkConfig {

}
