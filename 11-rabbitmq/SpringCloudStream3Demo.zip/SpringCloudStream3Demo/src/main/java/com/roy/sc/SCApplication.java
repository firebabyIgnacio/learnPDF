package com.roy.sc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author roy
 * @desc
 */
@SpringBootApplication
public class SCApplication {
    public static void main(String[] args) {
        SpringApplication.run(SCApplication.class,args);
    }
}
