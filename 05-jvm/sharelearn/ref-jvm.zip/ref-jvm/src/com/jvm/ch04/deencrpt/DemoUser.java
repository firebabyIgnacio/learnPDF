package com.jvm.ch04.deencrpt;
/*
* 类说明：我们要处理的业务类
 */

public class DemoUser {

	private int id = 13;
	private String name = "King";

	@Override
	public String toString() {
		return "DemoUser [id=" + id + ", name=" + name + "]";
	}


}
