package com.jvm.ch04.clazzload;

/**
 * @author 【享学课堂】 King老师
 * 类加载--子类
 */
public class SubClaszz extends SuperClazz {
	static{
		System.out.println("SubClass init！");
	}

}
