package com.jvm.ch07.p2;

import java.util.Arrays;

/**
 * 不需要实例化的类应该构造器私有
 */
public class Demo {
    public static void main(String[] args) {
        //Tools tools = new Tools();
        Tools.find13();
        Arrays.asList("king","Mark");
    }

}
