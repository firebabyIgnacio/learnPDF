package com.jvm.ch07.p10;

import java.util.Collections;
import java.util.List;

/**
 *工具类
 */
public  class Tools {
    private Tools(){
    }
    public static List find13(){
        ///啪啪啪的代码
        //return null;
        return Collections.EMPTY_LIST;
    }

    public static void main(String[] args) {
        List list = find13();
        if(list ==null){
            //空处理
        }

    }
}
