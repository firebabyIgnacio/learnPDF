package com.jvm.ch07.p2;

/**
 *工具类
 */
public  class Tools {
    private Tools(){//私有化的构造方法

    }
    public static void find13(){
    }
}
