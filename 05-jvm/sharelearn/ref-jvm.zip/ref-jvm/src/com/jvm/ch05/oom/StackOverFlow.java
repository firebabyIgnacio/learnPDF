package com.jvm.ch05.oom;


import java.io.InputStream;
import java.nio.ByteBuffer;

/**
 * 享学课堂——栈溢出   1M *5000线程同时在跑 =5G 内存小于5G
 */
public class StackOverFlow {

    public void king(){
        king();//死递归
     }
    public static void main(String[] args)throws Throwable {
        StackOverFlow javaStack = new StackOverFlow();
        javaStack.king();
    }
}
