package com.xiangxue;

import java.math.BigDecimal;
import java.util.Date;

/**
 */
public class FutureContract {
    BigDecimal bigDecimal1;
    BigDecimal bigDecimal2;
    BigDecimal bigDecimal3;
    BigDecimal bigDecimal4;
    BigDecimal bigDecimal5;
    BigDecimal bigDecimal6;
    BigDecimal bigDecimal7;
    BigDecimal bigDecimal8;
    BigDecimal bigDecimal9;
    BigDecimal bigDecimal10;
    BigDecimal bigDecimal11;
    BigDecimal bigDecimal12;
    BigDecimal bigDecimal13;
    BigDecimal bigDecima114;
    BigDecimal bigDecimal15;
    BigDecimal bigDecimal16;
    Long long1;
    Long long2;
    Long long3;
    String string1;
    String string2;
    String string3;
    Integer integer1;
    Integer integer2;
    Integer integer3;
    Integer integer4;
    Date date1;
    Date date2;

    public FutureContract(BigDecimal bigDecimal1, Long long1, String string1, Integer integer1, Date date1) {
        this.bigDecimal1 = bigDecimal1;
        this.long1 = long1;
        this.string1 = string1;
        this.integer1 = integer1;
        this.date1 = date1;
    }

    public BigDecimal getBigDecimal1() {
        return bigDecimal1;
    }

    public void setBigDecimal1(BigDecimal bigDecimal1) {
        this.bigDecimal1 = bigDecimal1;
    }

    public BigDecimal getBigDecimal2() {
        return bigDecimal2;
    }

    public void setBigDecimal2(BigDecimal bigDecimal2) {
        this.bigDecimal2 = bigDecimal2;
    }

    public BigDecimal getBigDecimal3() {
        return bigDecimal3;
    }

    public void setBigDecimal3(BigDecimal bigDecimal3) {
        this.bigDecimal3 = bigDecimal3;
    }

    public BigDecimal getBigDecimal4() {
        return bigDecimal4;
    }

    public void setBigDecimal4(BigDecimal bigDecimal4) {
        this.bigDecimal4 = bigDecimal4;
    }

    public BigDecimal getBigDecimal5() {
        return bigDecimal5;
    }

    public void setBigDecimal5(BigDecimal bigDecimal5) {
        this.bigDecimal5 = bigDecimal5;
    }

    public BigDecimal getBigDecimal6() {
        return bigDecimal6;
    }

    public void setBigDecimal6(BigDecimal bigDecimal6) {
        this.bigDecimal6 = bigDecimal6;
    }

    public BigDecimal getBigDecimal7() {
        return bigDecimal7;
    }

    public void setBigDecimal7(BigDecimal bigDecimal7) {
        this.bigDecimal7 = bigDecimal7;
    }

    public BigDecimal getBigDecimal8() {
        return bigDecimal8;
    }

    public void setBigDecimal8(BigDecimal bigDecimal8) {
        this.bigDecimal8 = bigDecimal8;
    }

    public BigDecimal getBigDecimal9() {
        return bigDecimal9;
    }

    public void setBigDecimal9(BigDecimal bigDecimal9) {
        this.bigDecimal9 = bigDecimal9;
    }

    public BigDecimal getBigDecimal10() {
        return bigDecimal10;
    }

    public void setBigDecimal10(BigDecimal bigDecimal10) {
        this.bigDecimal10 = bigDecimal10;
    }

    public BigDecimal getBigDecimal11() {
        return bigDecimal11;
    }

    public void setBigDecimal11(BigDecimal bigDecimal11) {
        this.bigDecimal11 = bigDecimal11;
    }

    public BigDecimal getBigDecimal12() {
        return bigDecimal12;
    }

    public void setBigDecimal12(BigDecimal bigDecimal12) {
        this.bigDecimal12 = bigDecimal12;
    }

    public BigDecimal getBigDecimal13() {
        return bigDecimal13;
    }

    public void setBigDecimal13(BigDecimal bigDecimal13) {
        this.bigDecimal13 = bigDecimal13;
    }

    public BigDecimal getBigDecima114() {
        return bigDecima114;
    }

    public void setBigDecima114(BigDecimal bigDecima114) {
        this.bigDecima114 = bigDecima114;
    }

    public BigDecimal getBigDecimal15() {
        return bigDecimal15;
    }

    public void setBigDecimal15(BigDecimal bigDecimal15) {
        this.bigDecimal15 = bigDecimal15;
    }

    public BigDecimal getBigDecimal16() {
        return bigDecimal16;
    }

    public void setBigDecimal16(BigDecimal bigDecimal16) {
        this.bigDecimal16 = bigDecimal16;
    }

    public Long getLong1() {
        return long1;
    }

    public void setLong1(Long long1) {
        this.long1 = long1;
    }

    public Long getLong2() {
        return long2;
    }

    public void setLong2(Long long2) {
        this.long2 = long2;
    }

    public Long getLong3() {
        return long3;
    }

    public void setLong3(Long long3) {
        this.long3 = long3;
    }

    public String getString1() {
        return string1;
    }

    public void setString1(String string1) {
        this.string1 = string1;
    }

    public String getString2() {
        return string2;
    }

    public void setString2(String string2) {
        this.string2 = string2;
    }

    public String getString3() {
        return string3;
    }

    public void setString3(String string3) {
        this.string3 = string3;
    }

    public Integer getInteger1() {
        return integer1;
    }

    public void setInteger1(Integer integer1) {
        this.integer1 = integer1;
    }

    public Integer getInteger2() {
        return integer2;
    }

    public void setInteger2(Integer integer2) {
        this.integer2 = integer2;
    }

    public Integer getInteger3() {
        return integer3;
    }

    public void setInteger3(Integer integer3) {
        this.integer3 = integer3;
    }

    public Integer getInteger4() {
        return integer4;
    }

    public void setInteger4(Integer integer4) {
        this.integer4 = integer4;
    }

    public Date getDate1() {
        return date1;
    }

    public void setDate1(Date date1) {
        this.date1 = date1;
    }

    public Date getDate2() {
        return date2;
    }

    public void setDate2(Date date2) {
        this.date2 = date2;
    }
}
