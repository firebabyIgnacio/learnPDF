package cn.enjoyedu.framework.vo;

/**
 *类说明：方法本身运行是否正确的结果类型
 */
public enum TaskResultType {
	Success,Failure,Exception
}
