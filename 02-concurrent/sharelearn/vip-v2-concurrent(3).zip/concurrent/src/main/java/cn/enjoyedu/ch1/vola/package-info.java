/**
 * 类说明：volatile关键字的用处和缺点
 */
package cn.enjoyedu.ch1.vola;