/**
 * @author Mark老师   享学课堂 https://enjoy.ke.qq.com
 * 往期课程咨询芊芊老师  QQ：2130753077 VIP课程咨询 依娜老师  QQ：2133576719
 * 说明：ch1包，主要演示线程基础、线程之间的共享和协作
 */
package cn.enjoyedu.ch1;