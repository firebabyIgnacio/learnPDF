package cn.enjoyedu.ch7.safeclass.safepublish;

/**
 * 类说明：
 */
public final class FinalUserVo {
    private int age;

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
