/**
 * 类说明：等待超时模式实现一个数据库连接池
 */
package cn.enjoyedu.ch1.pool;