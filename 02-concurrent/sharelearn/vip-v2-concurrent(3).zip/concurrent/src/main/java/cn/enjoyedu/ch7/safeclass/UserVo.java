package cn.enjoyedu.ch7.safeclass;

/**
 * 类说明：
 */
public class UserVo {
    private int age;

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
