/**
 * 类说明：Java中线程基本概念和常见方法
 */
package cn.enjoyedu.ch1.base;