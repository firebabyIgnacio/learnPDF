package cn.enjoyedu.ch7.safeclass;

/**
 * 无状态的类
 */
public class StatelessClass {
	public int service(int a,int b){

	    return a+b;
    }

    public void serviceUser(UserVo user){
        //do sth user
    }


}
