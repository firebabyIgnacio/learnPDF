/**
 * 类说明：演示wait/notify/notifyAll的用法，和notify/notifyAll的区别
 */
package cn.enjoyedu.ch1.wn;