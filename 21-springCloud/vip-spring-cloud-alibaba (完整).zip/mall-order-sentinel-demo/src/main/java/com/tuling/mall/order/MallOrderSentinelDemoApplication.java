package com.tuling.mall.order;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MallOrderSentinelDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(MallOrderSentinelDemoApplication.class, args);
    }

}
