package com.tuling.malluserloadbalancerdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MallUserLoadbalancerDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
