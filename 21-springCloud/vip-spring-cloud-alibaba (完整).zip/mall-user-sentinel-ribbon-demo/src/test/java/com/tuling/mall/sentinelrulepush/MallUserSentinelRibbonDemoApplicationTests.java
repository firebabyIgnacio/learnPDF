package com.tuling.mall.sentinelrulepush;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MallUserSentinelRibbonDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
