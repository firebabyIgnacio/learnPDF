package com.tuling.mall.sentinelrulepush.controller;

import com.alibaba.csp.sentinel.annotation.SentinelResource;
import com.alibaba.csp.sentinel.slots.block.BlockException;
import com.tuling.common.utils.R;
import com.tuling.mall.sentinelrulepush.common.ExceptionUtil;
import com.tuling.mall.sentinelrulepush.feign.OrderFeignService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.util.concurrent.atomic.AtomicInteger;


/**
 * 
 *
 * @author fox
 * @email 2763800211@qq.com
 * @date 2021-01-28 15:53:24
 */
@RestController
@RequestMapping("/user")
public class UserController {


    @Autowired
    OrderFeignService orderFeignService;

    @RequestMapping(value = "/findOrderByUserId/{id}")
    @SentinelResource(value = "findOrderByUserId",
            blockHandlerClass = ExceptionUtil.class,blockHandler = "handleException",
            fallbackClass = ExceptionUtil.class,fallback = "fallback")
    public R  findOrderByUserId(@PathVariable("id") Integer id) {

        //feign调用
        R result = orderFeignService.findOrderByUserId(id);

        return result;
    }

    @SentinelResource(value = "hot")
    @RequestMapping("/hot")
    public String hot(String a,String b){
        return a+b;
    }


    AtomicInteger atomicInteger = new AtomicInteger();

    @RequestMapping("/test2")
    public String test2() {
        atomicInteger.getAndIncrement();
        if (atomicInteger.get() % 2 == 0){
            //模拟异常和异常比率
            int i = 1/0;
        }

        return "========test2()";
    }

}
