package com.tuling.dubbo.user;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCloudDubboProviderUserApplicationTests {

    @Test
    void contextLoads() {
    }

}
