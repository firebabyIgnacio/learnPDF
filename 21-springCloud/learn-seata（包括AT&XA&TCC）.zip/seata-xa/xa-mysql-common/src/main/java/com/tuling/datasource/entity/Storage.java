package com.tuling.datasource.entity;

import lombok.Data;

/**
 * @author Fox
 */
@Data
public class Storage {
    private Integer id;
    
    private String commodityCode;
    
    private Integer count;
    
}
