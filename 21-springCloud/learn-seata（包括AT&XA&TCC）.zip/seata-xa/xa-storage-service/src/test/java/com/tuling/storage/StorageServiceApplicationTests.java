package com.tuling.storage;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StorageServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
